import requests
import shutil
import datetime
import time
import os
#import cv2 as cv

now = datetime.datetime.now()
#url = "https://docs.opencv.org/3.4/opencv-logo-small.png"
url = "http://192.168.32.51:8000/stream.jpg"
timen = str(now.time())
rts = str(now)
file_name = "img.jpg"
file_name1 = rts[0:10]+"/"+timen[0]+timen[1]+timen[3]+timen[4]+timen[6]+timen[7]+"img.jpg"
os.makedirs(os.path.dirname(rts[0:10]+"/"), exist_ok=True)
print(file_name)

#res = requests.get(url, stream = True)

while True:
    try:
        res = requests.get(url, stream = True, timeout = 90)
        if res.status_code == 200:
            with open(file_name,'wb') as f:
                shutil.copyfileobj(res.raw, f)
            print('Ok')
            now = datetime.datetime.now()
            timen = str(now.time())
            rts = str(now)
            file_name1 = rts[0:10]+"/"+timen[0]+timen[1]+timen[3]+timen[4]+timen[6]+timen[7]+"img.jpg"
            os.makedirs(os.path.dirname(rts[0:10]+"/"), exist_ok=True)
            crt = open(file_name1,'wb')
            inn = open(file_name, 'rb')
            crt.write(inn.read())
            crt.close()
            time.sleep(1)
            x=5

           # img = cv.imread("img.jpg")
        
            #temp = img
           # cv.imshow("CAM",temp)
           # cv.imshow(str(x),img)
           # cv.waitKey(20)
            #img.release()
           # cv.destroyAllWindows()
        
            #cv.destroyWindow("CAM")
    
        else:
            print('nok')
    except requests.exceptions.Timeout:
            print('conn timed')
    except Exception:
        pass
