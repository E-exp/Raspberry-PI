camera.service - copy this file to /lib/systemd/system/ and run sudo systemctl daemon-reload and sudo systemctl enable camera.service to start the service

rpca1.py - copy this file to /home/pi/camera/ - this script runs the streaming service on the rpi

in.py - run this file on your computer with access to the rpi adress, make sure to enter the correct rpi ip adress in the url variable.